#ifndef TSRM_STRTOK_R
#define TSRM_STRTOK_R

char *tsrm_strtok_r(char *s, const char *delim, char **last);

#endif
